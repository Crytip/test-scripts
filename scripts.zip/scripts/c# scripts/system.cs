﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class system : MonoBehaviour
{
    public GameObject ground;
    public int difficulty = 1;
    public int[,] gates;
    public List<GameObject> spawners = new List<GameObject>();
    public bool waveisover = false;//wave variable
    public int enemy_spawned = 0;
    private int spawner_count = 0;
    public int enemycountforthewave = 0;//how many enemy will spawn for the current wave
    public int enemydeathcount = 0;
    public int wavecount = 0;
    public int gem = 1000;
    public int width;
    public GameObject artificial_spawner;
    public GameObject target;
    public GameObject targetinstant;// this will give the spawner a target since those will only be used when attacking it can give the target on both sides
                                    //it will still work

    public Button onetouchspawn_button;
    public bool onetouchspawn = true;
    public Button linespawn_button;
    public bool linespawn = false;
    public Button choosetarget_button;
    public bool choosetarget = false;
    public Button academy_button;
    private bool academy = false;
    public Button pause_button;
    private bool pause = false;
    public Button switch_button;
    private bool switchbool = false;
    public Button mob1_button;
    public bool mob1 = true;
    public Button mob2_button;
    public bool mob2 = false;
    public Button mob3_button;
    public bool mob3 = false;

    public int choosenmob = 1;


    public Text moneytext;
    public Text waveinfo;

    public List<GameObject> spawnedbluemobs = new List<GameObject>();
    public Vector3 gatheringtarget;
    public GameObject testobject;//delete this later this will be used for only test purposes
    public GameObject testobject2;


    List<Vector3> gathering_point_points = new List<Vector3>();
    int gathering_solider_count = 15;
    public bool enemygathering = false;
    private int gatheringpointgiven = 0;
    public List<GameObject> gathering_enemies = new List<GameObject>();

    public Vector3 artificial_spawner_place;
    public int id_of_spawner_of_spawnerforwave;
    public GameObject spawnertobe;//artificial spawner since its only one object dont need to pull it from object pooling


    private void Start()
    {
        onetouchspawn_button.GetComponent<Image>().color = Color.red;
        onetouchspawn = true;

        width = ground.GetComponent<prefabterraingen>().width;

        mob1_button.GetComponent<Image>().color = Color.green;
        mob1 = true;
        gem = 200;
        moneytext.text = string.Format("Gem: {0}", gem);
        waveinfo.enabled = false;
        StartCoroutine(startwavecorbegining());
        
        
    }
    IEnumerator startwavecorbegining()
    {
        yield return new WaitForSeconds(0.1f);
        if (ground.GetComponent<prefabterraingen>().donewiththeterrain)
        {
            startwave();
        }
        else
        {
            StartCoroutine(startwavecorbegining());
        }
    }
    public void ounetouchspawnfunc()
    {
        if (!onetouchspawn)
        {
            onetouchspawn_button.GetComponent<Image>().color = Color.red;
            onetouchspawn = true;
            if (linespawn)
            {
                linespawn = false;
                linespawn_button.GetComponent<Image>().color = Color.white;
            }
            else
            {
                choosetarget = false;
                choosetarget_button.GetComponent<Image>().color = Color.white;
            }
        }
        
        
    }

    public void linespawnfunc()
    {
        if (!linespawn)
        {
            linespawn_button.GetComponent<Image>().color = Color.red;
            linespawn = true;
            if (onetouchspawn)
            {
                onetouchspawn = false;
                onetouchspawn_button.GetComponent<Image>().color = Color.white;
            }
            else
            {
                choosetarget = false;
                choosetarget_button.GetComponent<Image>().color = Color.white;
            }
        }
    }

    public void choosetargetfunc()
    {
        if (!choosetarget)
        {
            choosetarget_button.GetComponent<Image>().color = Color.red;
            choosetarget = true;
            if (onetouchspawn)
            {
                onetouchspawn = false;
                onetouchspawn_button.GetComponent<Image>().color = Color.white;
            }
            else
            {
                linespawn = false;
                linespawn_button.GetComponent<Image>().color = Color.white;
            }
        }
    }

    public void changemob(int mobid)
    {
        choosenmob = mobid;
        if (choosenmob == 1)
        {
            mob1_button.GetComponent<Image>().color = Color.green;
            mob1 = true;
            mob2_button.GetComponent<Image>().color = Color.white;
            mob2 = false;
            mob3_button.GetComponent<Image>().color = Color.white;
            mob3 = false;
        }
        else if (choosenmob == 2)
        {
            mob1_button.GetComponent<Image>().color = Color.white;
            mob1 = false;
            mob2_button.GetComponent<Image>().color = Color.green;
            mob2 = true;
            mob3_button.GetComponent<Image>().color = Color.white;
            mob3 = false;
        }
        else if (choosenmob == 3)
        {
            mob1_button.GetComponent<Image>().color = Color.white;
            mob1 = false;
            mob2_button.GetComponent<Image>().color = Color.white;
            mob2 = false;
            mob3_button.GetComponent<Image>().color = Color.green;
            mob3 = true;

        }
    }
    public void spawntarget(int x, int y)
    {
        targetinstant = Instantiate(target);
        targetinstant.transform.position = new Vector3(x,0,y);
    }
    public void gateup(int[,] list, int lengt)
    {
        gates = list;
        int[] choose_list = new int[lengt]; // this will choose if the spawner is choosen the index will be same with the spawner id if 0 not if 1 yes
        spawner_count = lengt;
        //Debug.Log(gates[0,0]);
        for (int i = 0; i < lengt; i++)
        {
            Vector3 position;
            if (gates[i,0] == 1)//left done
            {
                position = new Vector3(width + 2, 0,gates[i,1]);
                Debug.Log("debuging the position ");
                Debug.Log(position);

            }
            else if (gates[i,0] == 2)//right
            {
                position = new Vector3(-2, 0, gates[i, 1]);
            }
            else if (gates[i,0] == 3)//up done
            {
                position = new Vector3(gates[i, 1], 0, -2);
            }
            else//down
            {
                position = new Vector3(gates[i, 1], 0, width + 2);
            }

            choose_list[i] = Random.Range(0,2);
            GameObject obj = objectpooling.current.get_gatespawner();
            obj.transform.position = position;
            obj.GetComponent<spawner>().artificial_spawner = artificial_spawner;
            if (choose_list[i] == 0)
            {
                obj.GetComponent<spawner>().choosen = false;
            }
            else
            {
                obj.GetComponent<spawner>().choosen = true;
            }
            obj.GetComponent<spawner>().id = i;
            obj.GetComponent<spawner>().system = gameObject;
            obj.GetComponent<spawner>().target = targetinstant;
            obj.GetComponent<spawner>().spawnertobe = spawnertobe;
            spawners.Add(obj);
            obj.SetActive(true);


        }
        

    }
    //okay this will create a gathering target on height 0 will decide how many soldiers will gather there. there is a need for another func to update 
    //and check if the soldier count for the decided gathering target are spawned then we need to check if they are indeed gathered there
    private void chooseagatheringtarget()
    {
        bool checkbool = true;
        float[,] heights = ground.GetComponent<prefabterraingen>().heights;
        int z = Random.Range(1,2);//this will decide if there will be a gathering in this wave its %50 on every fifth wave there will be a spawner mission
        if(z == 1 && wavecount % 5 != 0)
        {
            enemygathering = true;
            gathering_point_points.Clear();
            gathering_solider_count = 25;
            gathering_solider_count += difficulty * wavecount;
            gathering_enemies.Clear();
            gatheringpointgiven = 0;
            StartCoroutine(checkformoveorder());//will check if the mobs are in place and will move them to attack
            while (checkbool)
            {
                int x = Random.Range(10, width - 10);
                int y = Random.Range(10, width - 10);
                //Debug.Log("looking for a suitable place");
                if (heights[x, y] <= 0.1f && heights[x + 6, y + 6] <= 0.1f && heights[x + 6, y] <= 0.1f && heights[x - 6, y - 6] <= 0.1f && heights[x - 6, y] <= 0.1f && heights[x + 6, y - 6] <= 0.1f && heights[x, y - 6] <= 0.1f && heights[x - 6, y + 6] <= 0.1f && heights[x, y + 6] <= 0.1f)
                {
                    gatheringtarget = new Vector3(y, 0, x);
                    if (Vector3.Distance(gatheringtarget,targetinstant.transform.position) > 25)
                    {
                        Debug.Log("Creating additional target for gathering");
                        Debug.Log(gathering_solider_count);
                        checkbool = false;
                        //for (int i = 0; i < 9; i++)//test purposes
                        //{
                            //    GameObject objl = Instantiate(testobject2);
                            //    if(i == 0)
                            //    {
                            //        objl.transform.position = new Vector3(y, 0, x);
                            //}
                            //else if (i == 1)
                            //{
                            //    objl.transform.position = new Vector3(y+6, 0, x+6);
                            //}
                            //else if (i == 2)
                            //{
                            //    objl.transform.position = new Vector3(y-6, 0, x+6);
                            //}
                            //else if (i== 3)
                            //{
                            //    objl.transform.position = new Vector3(y+6, 0, x-6);
                            //}
                            //else if(i == 4)
                            //{
                            //    objl.transform.position = new Vector3(y-6, 0, x-6);
                            //}
                            //else if (i == 5)
                            //{
                            //    objl.transform.position = new Vector3(y - 6, 0, x);
                            //}
                            //else if (i == 6)
                            //{
                            //    objl.transform.position = new Vector3(y + 6, 0, x);
                            //}
                            //else if (i == 7)
                            //{
                            //    objl.transform.position = new Vector3(y , 0, x -6);
                            //}
                            //else if (i == 8)
                            //{
                            //    Debug.Log("comes here");
                            //    objl.transform.position = new Vector3(y, 0, x + 6);
                            //}

                        //}
                        int created_gathering_soldiers = 0;
                        for (int i = 0; i < (int)(gathering_solider_count / 5) + 1; i++)//this too is for test purposes but might be usable so leave it
                        {
                            for (int c = 0; c < 5; c++)
                            {
                                created_gathering_soldiers += 1;
                                if (created_gathering_soldiers <= gathering_solider_count)
                                {
                                    int xcord = (y - 2) + c * 2;
                                    int zcord = x -3 + i * 2;

                                    gathering_point_points.Add(new Vector3(xcord, 0.5f, zcord));
                                    //GameObject obj = Instantiate(testobject);//test purposes
                                    //obj.transform.position = new Vector3(xcord, 0.5f, zcord);
                                }
                                else
                                {
                                    return;
                                }
                            }

                        }
                    }
                    
                    
                }
            }
            
        }
        else
        {
            enemygathering = false;
        }
        
    }

    public Vector3 getgatheringpoint()
    {
        if(gatheringpointgiven < gathering_point_points.Count)
        {
            gatheringpointgiven += 1;
            return gathering_point_points[gatheringpointgiven-1];
            
        }
        else
        {
            return targetinstant.transform.position;
        }
    }

    public void startwave()
    {
        waveisover = true;
        wavecount += 1;
        enemycountforthewave = Random.Range(30+((difficulty+wavecount)*10),51 + ((difficulty + wavecount) * 10));
        Debug.Log(enemycountforthewave);
        enemy_spawned = 0;
        enemydeathcount = 0;
        StartCoroutine(startwavecor());
        chooseagatheringtarget();
        if(wavecount % 1 == 0)//wavecount = 1 test için duruyo
        {
            choosespawnerplace();
        }
    }
    public void finishwave()
    {
        waveisover = true;
        startwave();

    }

    private void choosespawnerplace()
    {
        float[,] heights = ground.GetComponent<prefabterraingen>().heights;
        bool checkboolv1 = true;
        id_of_spawner_of_spawnerforwave = Random.Range(0,spawner_count);
        while (checkboolv1)
        {
            int x = Random.Range(10, width - 10);
            int y = Random.Range(10, width - 10);
            if (heights[x, y] <= 0.1f && heights[x + 4, y + 4] <= 0.1f && heights[x + 4, y] <= 0.1f && heights[x - 4, y - 4] <= 0.1f && heights[x - 4, y] <= 0.1f && heights[x + 4, y - 4] <= 0.1f && heights[x, y - 4] <= 0.1f && heights[x - 4, y + 4] <= 0.1f && heights[x, y + 4] <= 0.1f)
            {
                artificial_spawner_place = new Vector3(y,0,x);
                if (Vector3.Distance(artificial_spawner_place, targetinstant.transform.position) > 20)
                {
                    checkboolv1 = false;
                    //GameObject obj = Instantiate(testobject2);
                    //obj.transform.position = artificial_spawner_place;
                }
                
            }
        }
        spawners[id_of_spawner_of_spawnerforwave].GetComponent<spawner>().spawnerspawn();

    }


    void start_attacking()
    {
        for (int i = 0; i < gathering_enemies.Count; i++)
        {
            if (gathering_enemies[i].activeInHierarchy)
            {
                gathering_enemies[i].GetComponent<redmob1sc>().target = targetinstant.transform.position;
            }
        }
        enemygathering = false;
    }

    IEnumerator checkformoveorder()
    {
        yield return new WaitForSeconds(0.2f);
        bool can_start_attacking = false;
        if (gathering_enemies.Count == gathering_solider_count)
        {
            can_start_attacking = true;
            Debug.Log("gathering enemies count has reached gathering soldier count(int)");
            for (int i = 0; i < gathering_enemies.Count; i++)
            {
                if (gathering_enemies[i].activeInHierarchy)
                {
                    if (gathering_enemies[i].GetComponent<redmob1sc>().agent.hasPath && Vector3.Distance(gathering_enemies[i].GetComponent<redmob1sc>().agent.destination,gathering_enemies[i].transform.position) > 2)
                    {
                        can_start_attacking = false;
                    }

                }
            }
        }
        if (can_start_attacking)
        {
            start_attacking();
            Debug.Log("why did this got hit");
        }
        if (enemygathering)
        {
            StartCoroutine(checkformoveorder());
        }
    }

    IEnumerator startwavecor()
    {
        waveinfo.enabled = true;
        waveinfo.text = string.Format("{0}. Wave in 15..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 14..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 13..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 12..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 11..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 10..",wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 9..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 8..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 7..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 6..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 5..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 4..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 3..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 2..", wavecount);
        yield return new WaitForSeconds(1);
        waveinfo.text = string.Format("{0}. Wave in 1..", wavecount);
        yield return new WaitForSeconds(1);
        waveisover = false;
        
        waveinfo.text = "Protect your Gem!";//this will be changed according to the game mode if defense protect your game if attack kill them all
        yield return new WaitForSeconds(1);
        waveinfo.enabled = false;
    }

    public void updateenemycount(int count)
    {
        enemy_spawned += count;
        if(enemy_spawned >= enemycountforthewave)
        {
            waveisover = true;
            
        }

    }
    public void updateenemydeathcount()//add a game object to this so that we can make a copy of them
    {
        enemydeathcount += 1;
        //Debug.Log(enemydeathcount);
        gem += 8;
        moneytext.text = string.Format("Gem: {0}", gem);
        if (enemydeathcount == enemy_spawned)
        {
            finishwave();
        }
    }

    public void updatemoneytext()
    {
        moneytext.text = string.Format("Gem: {0}", gem);
    }
    public void notenoughgem()
    {
        StartCoroutine(outofgem());
    }

    IEnumerator outofgem()
    {
        yield return new WaitForSeconds(0.2f);
        moneytext.color = Color.red;
        yield return new WaitForSeconds(0.2f);
        moneytext.color = Color.black;
        yield return new WaitForSeconds(0.2f);
        moneytext.color = Color.red;
        yield return new WaitForSeconds(0.2f);
        moneytext.color = Color.black;
    }
}
