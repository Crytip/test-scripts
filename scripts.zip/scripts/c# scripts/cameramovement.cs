﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class cameramovement : MonoBehaviour
{
    public GameObject target;
    private int slider_multipler = 20;
    private int highness = 40;
    public GameObject terra;
    public Joystick joystick;
    private bool waitingspawn_countdown = false;
    public GameObject system;
    public GameObject lineeffect;
    private GameObject lineparticleeffect;

    private bool firstclick = false;

    private Vector3 linepoint1;
    private Vector3 linepoint2;


    public GameObject testcolider;
    private GameObject testcolidercurrent;
    private bool started_drawing_line = false;
    private bool waiting_linecountdown = false;
    private int linemobid = 0;

    

    void Start()
    {
        //transform.position = new Vector3(terra.GetComponent<terrainGenerator>().width/2, highness, terra.GetComponent<terrainGenerator>().width / 2);-----disable point
        transform.position = new Vector3(64,highness,64);
        transform.rotation = Quaternion.Euler(70, 180, 0);
        testcolidercurrent = Instantiate(testcolider);
        testcolidercurrent.transform.position = new Vector3(300,300,300);

        lineparticleeffect = Instantiate(lineeffect);
        lineparticleeffect.transform.position = new Vector3(300, 300, 300);
        lineparticleeffect.SetActive(false);

    }

    private void Update()
    {
        if (Input.GetButtonDown("Fire1") && system.GetComponent<system>().onetouchspawn)
        {
            shoot();
        }
        
        if (Input.GetButtonDown("Fire1") && system.GetComponent<system>().linespawn && !waiting_linecountdown)
        {
            if (!EventSystem.current.IsPointerOverGameObject(-1))    // is the touch on the GUI
            {
                RaycastHit hit;
                Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
                if (Physics.Raycast(ray, out hit))
                {
                    if (hit.collider != null)
                    {
                        if (hit.point.y < 1)
                        {
                            shootmini();
                            started_drawing_line = true;
                            Debug.Log(started_drawing_line);
                        }
                    }
                }
                
            }
            
            
        }
        if (Input.GetButtonUp("Fire1") && system.GetComponent<system>().linespawn && started_drawing_line )
        {
            firstclick = false;
            linepoint1 = this.GetComponent<LineRenderer>().GetPosition(0);
            linepoint2 = this.GetComponent<LineRenderer>().GetPosition(1);

            lineparticleeffect.transform.position = linepoint1;
            lineparticleeffect.transform.LookAt(linepoint2);
            lineparticleeffect.transform.position = Vector3.Lerp(linepoint1, linepoint2, .5f);
            lineparticleeffect.transform.localScale = new Vector3(Vector3.Distance(linepoint1, linepoint2), 1, 1);
            lineparticleeffect.transform.Rotate(0, 90, 0);
            lineparticleeffect.SetActive(true);

            started_drawing_line = false;
            if (system.GetComponent<system>().mob1)
            {
                Debug.Log("line spawning the mob1");
                linemobid = 1;
                waiting_linecountdown = true;
                StartCoroutine(linespawncountdown());
                
            }
            else if (system.GetComponent<system>().mob2)
            {
                Debug.Log("line spawning the mob2");
                linemobid = 2;
                waiting_linecountdown = true;
                StartCoroutine(linespawncountdown());
            }
            else if (system.GetComponent<system>().mob3)
            {
                Debug.Log("line spawning the mob3");
            }

        }
        if (firstclick)//do this as long as the button is down
        {
            shootmini();
        }
        transform.position = new Vector3(transform.position.x-joystick.Horizontal*40*Time.deltaTime, highness, transform.position.z-joystick.Vertical*40*Time.deltaTime);
        transform.position = new Vector3(Mathf.Clamp(transform.position.x,45,80),transform.position.y,Mathf.Clamp(transform.position.z, 45, 119));
    }

    private void shoot()
    {
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

        if (EventSystem.current.IsPointerOverGameObject(-1))    // is the touch on the GUI
        {
            return;
        }
        if (waitingspawn_countdown)
        {
            return;
        }
        if (Physics.Raycast(ray, out hit))
        {
            if(hit.collider != null)
            {
                if (hit.point.y > 1)
                {
                    return;
                }
                
                if (system.GetComponent<system>().mob1)
                {
                    Debug.Log(hit.point);
                    if (system.GetComponent<system>().gem-10 >=0)
                    {
                        system.GetComponent<system>().gem -= 10;
                        system.GetComponent<system>().updatemoneytext();
                        GameObject obj = objectpooling.current.get_bluemob1();
                        obj.transform.position = new Vector3(hit.point.x, hit.point.y + 0.5f, hit.point.z);
                        obj.GetComponent<bluemob1sc>().target = system.GetComponent<system>().targetinstant.transform.position;
                        obj.GetComponent<bluemob1sc>().mission = "null";
                        obj.SetActive(true);
                        waitingspawn_countdown = true;
                        StartCoroutine(spawncountdown());
                    }
                    else
                    {
                        system.GetComponent<system>().notenoughgem();
                    }
                    
                }
                else if (system.GetComponent<system>().mob2)
                {
                    if (system.GetComponent<system>().gem-10 >=0)
                    {
                        //Debug.Log(hit.point);
                        system.GetComponent<system>().gem -= 10;
                        system.GetComponent<system>().updatemoneytext();
                        GameObject obj = objectpooling.current.get_bluemob2();
                        obj.transform.position = new Vector3(hit.point.x, hit.point.y + 0.5f, hit.point.z);
                        obj.GetComponent<bluemob1sc>().target = system.GetComponent<system>().targetinstant.transform.position;
                        obj.GetComponent<bluemob1sc>().mission = "null";
                        obj.SetActive(true);
                        waitingspawn_countdown = true;
                        StartCoroutine(spawncountdown());//bu şekilde devam edicek tüm mavi moblar için
                    }
                    
                }
                
            }
        }
    }


    private void shootmini()
    {
        RaycastHit hit;
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        
        if (Physics.Raycast(ray, out hit))
        {
            if (hit.collider != null)
            {
                if(hit.point.y > 1)
                {
                    return;
                }
                drawline(new Vector3(hit.point.x,hit.point.y+0.5f,hit.point.z));
            }
        }
       
    }
    private void drawline(Vector3 line)
    {
        if (!firstclick)
        {
            this.GetComponent<LineRenderer>().SetPosition(0,line);
            this.GetComponent<LineRenderer>().SetPosition(1, line);
            firstclick = true;
        }
        else
        {
            this.GetComponent<LineRenderer>().SetPosition(1, line);
            Debug.Log("ahy ay");
        }
    }
    IEnumerator spawncountdown()
    {
        yield return new WaitForSeconds(.5f);
        waitingspawn_countdown = false;
    }

    IEnumerator linespawncountdown()
    {
        yield return new WaitForSeconds(5);
        waiting_linecountdown = false;
        linespawn(linemobid);
        
        
    }

    private void linespawn(int x)
    {
        if (waiting_linecountdown)
        {
            return;
        }
        if (x == 1)
        {
            for (int i = 1; i < 11; i++)
            {
                float yey = i / 10f;
                testcolidercurrent.transform.position = Vector3.Lerp(linepoint1, linepoint2, yey);//this will be for checking if there is any kind of obj there 
                //not use atm
                
                //Debug.Log(Vector3.Angle(linepoint1, linepoint2));

                //if (terra.GetComponent<terrainGenerator>().heights[(int)testcolidercurrent.transform.position.z,(int)testcolidercurrent.transform.position.x] == 0)//the height lvl can be changed later
                //{//this has been changed and later will be added in with raycasting the scene and getting the height info********************
                    if (system.GetComponent<system>().gem-10 >=0)
                    {
                        //Debug.Log(1 / 10f);
                        system.GetComponent<system>().gem -= 10;
                        system.GetComponent<system>().updatemoneytext();
                        GameObject obj = objectpooling.current.get_bluemob1();
                        obj.transform.position = new Vector3(testcolidercurrent.transform.position.x, 0.5f, testcolidercurrent.transform.position.z);
                        obj.GetComponent<bluemob1sc>().target = system.GetComponent<system>().targetinstant.transform.position;
                        obj.GetComponent<bluemob1sc>().mission = "null";
                        obj.SetActive(true);
                        waiting_linecountdown = false;
                        lineparticleeffect.SetActive(false);
                        //Debug.Log(terra.GetComponent<terrainGenerator>().heights[1,1]);
                    }

                //}

            }
            this.GetComponent<LineRenderer>().SetPosition(0, new Vector3(0, 0, 0));
            this.GetComponent<LineRenderer>().SetPosition(1, new Vector3(0, 0, 0));
        }
        else if (x == 2)
        {
            for (int i = 1; i < 11; i++)
            {
                float yey = i / 10f;
                testcolidercurrent.transform.position = Vector3.Lerp(linepoint1, linepoint2, yey);
                //if (terra.GetComponent<terrainGenerator>().heights[(int)testcolidercurrent.transform.position.z, (int)testcolidercurrent.transform.position.x] == 0)//the height lvl can be changed later
                //{//this has been changed and later will be added in with raycasting the scene and getting the height info********************
                if (system.GetComponent<system>().gem-10 >= 0)
                    {
                        system.GetComponent<system>().gem -= 10;
                        system.GetComponent<system>().updatemoneytext();
                        Debug.Log(1 / 10f);
                        GameObject obj = objectpooling.current.get_bluemob2();
                        obj.transform.position = new Vector3(testcolidercurrent.transform.position.x, 0.5f, testcolidercurrent.transform.position.z);
                        obj.GetComponent<bluemob1sc>().target = system.GetComponent<system>().targetinstant.transform.position;
                        obj.GetComponent<bluemob1sc>().mission = "null";
                        obj.SetActive(true);
                        waiting_linecountdown = false;
                    }
                    
                    
                //}


            }
            this.GetComponent<LineRenderer>().SetPosition(0, new Vector3(0, 0, 0));
            this.GetComponent<LineRenderer>().SetPosition(1, new Vector3(0, 0, 0));
        }
        
    }

}
