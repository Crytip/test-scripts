import pygame
import tkinter
from time import sleep


root = tkinter.Tk()
width = root.winfo_screenwidth()
height = root.winfo_screenheight()
print(width)
print(height)

#pygame necessitys-------
pygame.init()


screen = pygame.display.set_mode((width,height),pygame.RESIZABLE)

#color variables--------
white = (255,255,255)
black = (0,0,0)


#gui images----
layer_gui_frame = pygame.image.load("layerframev2.png")
topology_gui_frame = pygame.image.load("topology_frame.png")
topology_background1 = pygame.image.load("red grid trap use only1.png")
topology_background2 = pygame.image.load("green grid switch use only1.png")
topology_background3 = pygame.image.load("purple grid route use only1.png")
topology_background4 = pygame.image.load("black grid all purpose1.png")
#main loop variable----
main_loop_bool = True


#layer gui variables------
layer_gui_frame_size_x = 270
layer_gui_frame_size_y = 800


#general variables-----
fullscreen_mode = False

#gui section------
def draw_layer_gui():
    screen.blit(layer_gui_frame,(width-layer_gui_frame_size_x,20))

def draw_topology_gui():
    screen.blit(topology_background4,(300,0))
    screen.blit(topology_gui_frame, (300, 0))


#main loop------
while main_loop_bool:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            main_loop_bool = False
        elif event.type == pygame.VIDEORESIZE:
            screen = pygame.display.set_mode((width,height),pygame.RESIZABLE)
            print()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if not fullscreen_mode:
                    screen = pygame.display.set_mode((width,height),pygame.FULLSCREEN)
                    fullscreen_mode = True
                    print("going full screen mode")
                else:
                    screen = pygame.display.set_mode((width, height), pygame.RESIZABLE)
                    fullscreen_mode = False
                    print("trying to exit")
    screen.fill(black)
    draw_layer_gui()
    draw_topology_gui()
    pygame.display.flip()